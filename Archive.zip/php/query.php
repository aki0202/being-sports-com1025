<?php
/* TASK 4.1: PHP code for connecting to the MySQL database */
//Database credentials
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "system25$");
define("DB_NAME", "com1025_cw_urn");

//Initiating connection with the database credentials above
$connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

/* TASK 4.2: PHP code for properly releasing a connection to the MySQL database */
mysqli_close($connection);

/* TASK 4.3: PHP code for querying the MySQL database */
$query = "SELECT COUNT(id), sport, instructor, duration, cost FROM online_bookings GROUP BY sport";

/* TASK 4.4: PHP code for reading data out of the result of a MySQL query */
$result = mysqli_query($connection, $query);

/* TASK 4.5: PHP code for properly freeing results of a MySQL query */
mysqli_free_result($result);

/* TASK 4.6: At least one dynamically constructed MySQL statement */
if (isset($_POST['submit']))
{
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];

    $insert_query = "INSERT INTO test(full_name, email) VALUES('".$full_name."', '".$email."')";
    $insert_result = mysqli_query($connection, $insert_query);
  
    if($insert_result)
    {
        echo "New bookings added successfully!";
    }else
    {
        echo "Unable to add bookings, please try again";
    }
    mysqli_free_result($insert_result);
}

/* TASK 4.7: PHP code for error handling around accessing the MySQL database */
if (mysqli_connect_error())
{
    
    $error_handling = "Unable to connect to database: ";
    $error_handling .= mysqli_connect_error();
    $error_handling .= " (" . mysqli_connect_errno . ")";
    echo $error_handling;
}

/* TASK 4.8: PHP scripts to handle the validation of the input data in PHP */
//If the form is submitted the following code will run
if (isset($_POST['submit']))
{
    //Here htmlspecialchars is used to prevent special characters from being inserted in our form input
    $full_name = htmlspecialchars($_POST['full_name']);
    $email = htmlspecialchars($_POST['email']);

    //This is a check to determine if the full name field is empty when submitted. If it is empty, return an error to the user
    if(isset($full_name) && $full_name == "") 
    {
        echo "$full_name field cannot be empty";
        header('location:index.php');
    }

    //This is a check to determine if the email field is empty when submitted. If it is empty, return an error to the user
    if(isset($email) && $email == "") 
    {
        echo "$email field cannot be empty";
        header('location:index.php');
    }

    //This is a check to determine if the email submitted is a valid email. If it is not a valid email, return an error to the user
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        echo " The $email entered is not a valid email. Please enter a valid email";
        header('location:index.php');
    }
}
?>