<!----
* Template Name: King Sport Arena
* Template URL: 
* Author: 
---->
<?php
    include('functions.php');
?>
<?php

    
    if (isset($_POST['submit']))
    {
        insertUser(
            //Getting data from form
            $first_name = htmlspecialchars($_POST['first_name']),
            $last_name = htmlspecialchars($_POST['last_name']),
            $gender = htmlspecialchars($_POST['gender']),
            $date_of_birth = htmlspecialchars($_POST['date_of_birth']),
            $address = htmlspecialchars($_POST['address']),
            $email = htmlspecialchars($_POST['email']),
            $password = htmlspecialchars($_POST['password']),
        );  
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Site title -->
    <title>King Sport Arena</title>
    <!----Custom CSS style-->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- header start here-->
    <header class="header" id="header">
        <!-- main menu start here-->
        <div class="header-main">
            <div class="container">
                <div class="row">
                    <div class="col-30">
                        <div class="logo">
                            <a href="index.php">
                                <img src="images/user.png" alt="King Sport Arena">
                            </a>
                        </div>
                    </div>
                    <div class="col-70">
                        <div class="main-header">
                            <div class="main-menu">
                                <nav>
                                    <ul>
                                        <li class="active"><a href="index.php">Home</a> </li>
                                        <li><a href="booking.php">Online Booking</a></li>
                                        <li><a href="membership.php">Membership</a></li>
                                        <li><a href="#">Swimming</a></li>
                                        <li><a href="#">Sports</a></li>
                                        <li><a href="#">Climbing</a></li>
                                        <li><a href="#">Facility Hire</a></li>
                                        <li><a href="#">Contact Us</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main menu end here-->
    </header>
    <!-- header area end here -->

    <!-- Hero section start here -->
    <div class="hero-section">
        <div class="container">
            <?php if(isset($_SESSION[$Error])): ?>
                <div class="alert alert-<?= $_SESSION['msg_type']; ?>">
                    <?php
                        echo $_SESSION[$Error];
                        unset($_SESSION[$Error]);

                    ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="hero">
                    <img src="images/media.jpg" alt="">
                </div>
                <div class="info container">
                    <h1>Welcome to King Sport Arena</h1>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. At, repudiandae veritatis. 
                        Rerum tenetur aut corrupti provident ad debitis hic, 
                        ullam laboriosam officiis doloremque laborum odit autem ex itaque. Eligendi, eius.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- slider section end here-->

    <div class="booking container">
        <div class="container">
            <div class="row">
                <form action="" method="POST" id="form" onsubmit="return checkInputs()" required>
                    <div class="input-form">
                        <div class="inputBox form-control">
                            <label for="">First Name :</label>
                            <input type="text" name="first_name" id="first_name" class="first_name" placeholder="First Name" >
                            <small>Error message</small>
                        </div>

                        <div class="inputBox form-control">
                            <label for="">Last Name :</label>
                            <input type="text" name="last_name" class="last_name" id="last_name" placeholder="Last Name" >
                            <small>Error message</small>
                        </div>

                        <div class="inputBox form-control">
                            <label for="">Gender :</label>
                            <input type="text" name="gender" class="gender" id="gender" placeholder="Gender" >
                            <small>Error message</small>
                        </div>

                        <div class="inputBox form-control">
                            <label for="">Date of Birth :</label>
                            <input type="date" name="date_of_birth" class="date_of_birth" id="date_of_birth" placeholder="Date of Birth" >
                            <small>Error message</small>
                        </div>

                        <div class="inputBox form-control">
                            <label for="">Address :</label>
                            <input type="text" name="address" class="address" id="address" placeholder="Address" >
                            <small>Error message</small>
                        </div>

                        <div class="inputBox form-control">
                            <label for="">Email Address :</label>
                            <input type="text" name="email" class="email" id="email" placeholder="Email Address" >
                            <small>Error message</small>
                        </div>

                        <div class="inputBox form-control">
                            <label for="">Password :</label>
                            <input type="text" name="password" class="password" id="password" placeholder="Password" >
                            <small>Error message</small>
                        </div>

                    </div>
                    <div class="d-flex">
                        <button class="submit" name="submit" id="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- footer section start here-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="copyright">
                    <p>&copy; <?=date('Y');?><b> King Sport Arena</b></p>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer section end here-->

    <!----custom script-->
    <script src="js/script.js"></script>
</body>
</html>