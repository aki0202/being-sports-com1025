<?php
    //Database credentials
    define("DB_SERVER", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "system25$");
    define("DB_NAME", "com1025_cw_urn");

    $connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
?>