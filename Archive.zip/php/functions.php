<?php
session_start();
include('database.php');
//Function for inserting user into the database
function insertUser($first_name = NULL, $last_name = NULL, $gender = NULL, $date_of_birth = NULL, $address = NULL, $email = NULL, $password = NULL)
{
    global $connection;
    global $Error;

    //Validating form data using php scripting
    if(isset($first_name) && $first_name == ""){ $_SESSION[$Error] = "First name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($last_name) && $last_name == ""){ $_SESSION[$Error] = "Last name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($gender) && $gender == ""){ $_SESSION[$Error] = "Gender field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($date_of_birth) && $date_of_birth == ""){ $_SESSION[$Error] = "Date of birth field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($address) && $address == ""){ $_SESSION[$Error] = "Address field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($email) && $email == ""){ $_SESSION[$Error] = "Email field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($password) && $password == ""){ $_SESSION[$Error] = "Password field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}

        if($Error == '')
        {
            $insert_query = "INSERT INTO user(first_name, last_name, gender, date_of_birth, address, email, password) 
                    VALUES('".$first_name."', '".$last_name."', '".$gender."', '".$date_of_birth."', '".$address."', '".$email."','".$password."')";
            $insert_result = mysqli_query($connection, $insert_query);
        
            if($insert_result)
            {
                $_SESSION[$Error] = "New user added successfully!";
                $_SESSION['msg_type'] = "success";
            }else
            {
                $_SESSION[$Error] = "Unable to add user!";
                $_SESSION['msg_type'] = "danger";
            }
        }else{
            $_SESSION[$Error] = "Unable to add user!";
            $_SESSION['msg_type'] = "danger";
        }
}

//Function for inserting membership into the database
function insertMembership($first_name = NULL, $last_name = NULL,$email = NULL, $start = NULL, $end = NULL)
{
    global $connection;
    global $Error;

    //Validating form data using php scripting
    if(isset($first_name) && $first_name == ""){ $_SESSION[$Error] = "First name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($last_name) && $last_name == ""){ $_SESSION[$Error] = "Last name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($email) && $email == ""){ $_SESSION[$Error] = "Email field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($start) && $start == ""){ $_SESSION[$Error] = "Date started field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($end) && $end == ""){ $_SESSION[$Error] = "Date of end field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}

        if($Error == '')
        {
            $insert_query = "INSERT INTO membership(first_name, last_name, email, start, end) 
                    VALUES('".$first_name."', '".$last_name."', '".$email."', '".$start."', '".$end."')";
            $insert_result = mysqli_query($connection, $insert_query);
            // echo $insert_query;
            if($insert_result)
            {
                $_SESSION[$Error] = "New member added successfully!";
                $_SESSION['msg_type'] = "success";
            }else
            {
                $_SESSION[$Error] = "Unable to add member!";
                $_SESSION['msg_type'] = "danger";
            }
        }else{
            $_SESSION[$Error] = "Unable to add member!";
            $_SESSION['msg_type'] = "danger";
        }
}

//Function for inserting booking into the database
function insertBooking($first_name = NULL, $last_name = NULL, $sport = NULL, $instructor = NULL,$no_of_seats = NULL, $cost = NULL)
{
    global $connection;
    global $Error;

    //Validating form data using php scripting
    if(isset($first_name) && $first_name == ""){ $_SESSION[$Error] = "First name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($last_name) && $last_name == ""){ $_SESSION[$Error] = "Last name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($sport) && $sport == ""){ $_SESSION[$Error] = "sport name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($instructor) && $instructor == ""){ $_SESSION[$Error] = "Instructor name field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($no_of_seats) && $no_of_seats == ""){ $_SESSION[$Error] = "Number of seat field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}
    if(isset($cost) && $cost == ""){ $_SESSION[$Error] = "Cost field cannot be empty"; 
        $_SESSION['msg_type'] = "danger";}

        if($Error == '')
        {
            $insert_query = "INSERT INTO online_bookings(user_id, first_name, last_name, sport, instructor, no_of_seats, cost) 
                    VALUES((SELECT id FROM user WHERE first_name='".$first_name."' AND last_name='".$last_name."'),
                    '".$first_name."', '".$last_name."', '".$sport."', '".$instructor."', '".$no_of_seats."', '".$cost."')";
            $insert_result = mysqli_query($connection, $insert_query);
            echo $insert_query;
            if($insert_result)
            {
                $_SESSION[$Error] = "Booking added successfully!";
                $_SESSION['msg_type'] = "success";
            }else
            {
                $_SESSION[$Error] = "Unable to add booking!";
                $_SESSION['msg_type'] = "danger";
            }
        }else{
            $_SESSION[$Error] = "Unable to add booking!";
            $_SESSION['msg_type'] = "danger";
        }
}
?>