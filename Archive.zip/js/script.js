// Navigation on scroll
//This makes the nav menu to stick to the top when scrolled
window.addEventListener("scroll", function(){
    const header = document.querySelector("header");
    header.classList.toggle('sticky', window.scrollY > 0);
});

//input form validation
const form = document.getElementById('form');
const first_name = document.getElementById('first_name');
const last_name = document.getElementById('last_name');
const gender = document.getElementById('gender');
const date_of_birth = document.getElementById('date_of_birth');
const address = document.getElementById('address');
const email = document.getElementById('email');
const password = document.getElementById('password');


//when the form is click, first prevent default for happening
form.addEventListener('submit', (event) => {
    
    checkInputs()

});

function checkInputs() {
    //get the values from the inputs
    const first_nameValue = first_name.value;
    const last_nameValue = last_name.value;
    const genderValue = gender.value;
    const date_of_birthValue = date_of_birth.value;
    const addressValue = address.value;
    const emailValue = email.value;
    const passwordValue = password.value;

    if(first_nameValue === '') {
        //show error message (add error class)
        setErrorFor(first_name, 'Please fill in your first name');
    } else {
        //add success class
        setSuccessFor(first_name);
    };
    if(last_nameValue === '') {
        //show error message (add error class)
        setErrorFor(last_name, 'Please fill in your last name');
    } else {
        //add success class
        setSuccessFor(last_name);
    };
    if(genderValue === '') {
        //show error message (add error class)
        setErrorFor(gender, 'Please fill in your gender');
    } else {
        //add success class
        setSuccessFor(gender);
    };
    if(date_of_birthValue === '') {
        //show error message (add error class)
        setErrorFor(date_of_birth, 'Please fill in your date of birth');
    } else {
        //add success class
        setSuccessFor(date_of_birth);
    };
    if(addressValue === '') {
        //show error message (add error class)
        setErrorFor(address, 'Please fill in your contact address');
    } else {
        //add success class
        setSuccessFor(address);
    };

    if(emailValue === '') {
        //show error message (add error class)
        setErrorFor(email, 'Please fill in your email');
    } else {
        //add success class
        setSuccessFor(email);
    };
    if(passwordValue === '') {
        //show error message (add error class)
        setErrorFor(password, 'Please fill in your password');
    } else {
        //add success class
        setSuccessFor(password);
    };
}

if(checkInputs){
    event.returnValue = true;
}

function setErrorFor(input, message) {
    const inputBox = input.parentElement;
    const small = inputBox.querySelector('small');

    //add error message inside small
    small.innerText = message;

    //add error class
    inputBox.className = 'inputBox error';

}

function setSuccessFor(input) {
    const inputBox = input.parentElement;

    //add error class
    inputBox.className = 'inputBox success';
    
}